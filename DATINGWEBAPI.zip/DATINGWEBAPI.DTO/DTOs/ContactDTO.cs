﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DATINGWEBAPI.DTO.DTOs
{
    public class ContactDTO
    {

    }
}
